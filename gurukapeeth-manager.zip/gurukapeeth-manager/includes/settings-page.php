<?php
/**
 * College Settings and Homepage Configurator Pages
 */

defined( 'ABSPATH' ) || exit;

function gurukapeeth_render_settings_page() {
	if ( isset( $_POST['gurukapeeth_save_settings'] ) && check_admin_referer( 'gurukapeeth_settings_nonce' ) ) {
		$settings = array(
			'college_name'        => sanitize_text_field( $_POST['college_name'] ?? '' ),
			'trust_name'          => sanitize_text_field( $_POST['trust_name'] ?? '' ),
			'trust_hindi'         => sanitize_text_field( $_POST['trust_hindi'] ?? '' ),
			'trust_reg_no'        => sanitize_text_field( $_POST['trust_reg_no'] ?? '' ),
			'college_subtitle'    => sanitize_text_field( $_POST['college_subtitle'] ?? '' ),
			'tagline'             => sanitize_text_field( $_POST['tagline'] ?? '' ),
			'affiliating_univ'    => sanitize_text_field( $_POST['affiliating_univ'] ?? '' ),
			'aishe_code'          => sanitize_text_field( $_POST['aishe_code'] ?? '' ),
			'naac_grade'          => sanitize_text_field( $_POST['naac_grade'] ?? '' ),
			'phone_primary'       => sanitize_text_field( $_POST['phone_primary'] ?? '' ),
			'phone_secondary'     => sanitize_text_field( $_POST['phone_secondary'] ?? '' ),
			'email_info'          => sanitize_email( $_POST['email_info'] ?? '' ),
			'email_principal'     => sanitize_email( $_POST['email_principal'] ?? '' ),
			'address'             => sanitize_textarea_field( $_POST['address'] ?? '' ),
			'map_embed_url'       => esc_url_raw( $_POST['map_embed_url'] ?? '' ),
			'facebook_url'        => esc_url_raw( $_POST['facebook_url'] ?? '' ),
			'youtube_url'         => esc_url_raw( $_POST['youtube_url'] ?? '' ),
			'marquee_announcement'=> sanitize_text_field( $_POST['marquee_announcement'] ?? '' ),
			'razorpay_key_id'     => sanitize_text_field( $_POST['razorpay_key_id'] ?? '' ),
			'razorpay_key_secret' => sanitize_text_field( $_POST['razorpay_key_secret'] ?? '' ),
			'admission_fee_ba'    => sanitize_text_field( $_POST['admission_fee_ba'] ?? '4000' ),
			'admission_fee_bsc'   => sanitize_text_field( $_POST['admission_fee_bsc'] ?? '6000' ),
			'frontend_url'        => esc_url_raw( $_POST['frontend_url'] ?? 'https://gurukepeeth-clg.vercel.app' ),
		);

		update_option( 'gurukapeeth_settings', $settings );
		echo '<div class="notice notice-success is-dismissible"><p>College Settings successfully saved and synced to Headless REST API!</p></div>';
	}

	$s = get_option( 'gurukapeeth_settings', array() );
	?>
	<div class="wrap gurukapeeth-admin-wrap">
		<h1>College Institutional Settings</h1>
		<p class="subtitle">Global institution details consumed across all React frontend views and statutory disclosures.</p>

		<form method="post" action="">
			<?php wp_nonce_field( 'gurukapeeth_settings_nonce' ); ?>
			<div class="gurukapeeth-form-grid">
				<div class="form-section">
					<h3>Institutional Identity</h3>
					<div class="form-row">
						<label>College Full Name:</label>
						<input type="text" name="college_name" value="<?php echo esc_attr( $s['college_name'] ?? 'GURUKRIPA SHIKSHAN SANSTHAN COLLEGE PEETH' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Managing Trust / Society Name:</label>
						<input type="text" name="trust_name" value="<?php echo esc_attr( $s['trust_name'] ?? 'Shree Narayan Shiksha Seva Samiti Peeth' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Trust / Society Hindi Name:</label>
						<input type="text" name="trust_hindi" value="<?php echo esc_attr( $s['trust_hindi'] ?? 'श्री नारायण शिक्षा सेवा समिति, पीठ' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Society Registration Number:</label>
						<input type="text" name="trust_reg_no" value="<?php echo esc_attr( $s['trust_reg_no'] ?? '55/DUNGARPUR/2013-14' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Subtitle / Category:</label>
						<input type="text" name="college_subtitle" value="<?php echo esc_attr( $s['college_subtitle'] ?? 'Undergraduate Degree College (Arts & Science)' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Institutional Motto / Tagline:</label>
						<input type="text" name="tagline" value="<?php echo esc_attr( $s['tagline'] ?? 'Nurturing Intellect, Cultivating Character, Empowering Society' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Affiliating University:</label>
						<input type="text" name="affiliating_univ" value="<?php echo esc_attr( $s['affiliating_univ'] ?? 'Govind Guru Tribal University (GGTU), Banswara' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>AISHE Code:</label>
						<input type="text" name="aishe_code" value="<?php echo esc_attr( $s['aishe_code'] ?? 'C-48902' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>NAAC Accreditation Status:</label>
						<input type="text" name="naac_grade" value="<?php echo esc_attr( $s['naac_grade'] ?? 'Accredited B+ (Cycle-1) / SSR in Progress' ); ?>" class="regular-text" />
					</div>
				</div>

				<div class="form-section">
					<h3>Official Contacts & Communications</h3>
					<div class="form-row">
						<label>Primary Phone (Secretary):</label>
						<input type="text" name="phone_primary" value="<?php echo esc_attr( $s['phone_primary'] ?? '+91 95874 33001' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Secondary Phone (Chairman):</label>
						<input type="text" name="phone_secondary" value="<?php echo esc_attr( $s['phone_secondary'] ?? '+91 96105 87077' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>IT & Admission Desk (Mr. Ramesh Chandra Pargi):</label>
						<input type="text" name="phone_admission" value="<?php echo esc_attr( $s['phone_admission'] ?? '+91 82092 77580' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>General Inquiry Email:</label>
						<input type="email" name="email_info" value="<?php echo esc_attr( $s['email_info'] ?? 'gurukripa.peeth@gmail.com' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Principal Office Email:</label>
						<input type="email" name="email_principal" value="<?php echo esc_attr( $s['email_principal'] ?? 'gurukripa.peeth@gmail.com' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Campus Postal Address:</label>
						<textarea name="address" rows="3" class="large-text"><?php echo esc_textarea( $s['address'] ?? 'Gurukripa Shikshan Sansthan College, Rati Ka Fala, Duka Bye Pass, Peeth, Tehsil Simalwara, Dungarpur, Rajasthan - 314406, India' ); ?></textarea>
					</div>
					<div class="form-row">
						<label>Marquee Top Alert Ticker Text:</label>
						<input type="text" name="marquee_announcement" value="<?php echo esc_attr( $s['marquee_announcement'] ?? 'Admissions Open 2026-27 for B.A. and B.Sc. Degree Programs — Apply Online Now!' ); ?>" class="large-text" />
					</div>
				</div>

				<div class="form-section" style="grid-column: 1 / -1; margin-top: 20px; border-top: 2px solid #e2e8f0; padding-top: 20px;">
					<h3>Online Admission Portal & Razorpay Payment Gateway</h3>
					<p style="color: #64748b; font-size: 13px; margin-bottom: 16px;">
						Configure the online admission fee structure and Razorpay API credentials. When keys are ready, paste your Key ID and Secret below to activate live collections.
					</p>
					<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
						<div class="form-row">
							<label>Razorpay Key ID (Key ID):</label>
							<input type="text" name="razorpay_key_id" value="<?php echo esc_attr( $s['razorpay_key_id'] ?? 'rzp_test_U20wtdVhNmd2T2' ); ?>" class="regular-text" style="width: 100%;" placeholder="rzp_live_... or rzp_test_..." />
							<p class="description" style="font-size: 11px; color: #64748b;">Available in your Razorpay Dashboard &rarr; Settings &rarr; API Keys.</p>
						</div>
						<div class="form-row">
							<label>Razorpay Key Secret:</label>
							<input type="password" name="razorpay_key_secret" value="<?php echo esc_attr( $s['razorpay_key_secret'] ?? 'q2VjlgPRx4S8XTtFIHRlhDRi' ); ?>" class="regular-text" style="width: 100%;" placeholder="••••••••••••••••" />
							<p class="description" style="font-size: 11px; color: #64748b;">Never shared with frontend. Kept secure on server for HMAC signature verification.</p>
						</div>
						<div class="form-row">
							<label>B.A. Admission Fee (INR):</label>
							<input type="number" name="admission_fee_ba" value="<?php echo esc_attr( $s['admission_fee_ba'] ?? '4000' ); ?>" class="regular-text" style="width: 100%;" />
							<p class="description" style="font-size: 11px; color: #64748b;">Annual / Admission fee charged for B.A. Arts applicants.</p>
						</div>
						<div class="form-row">
							<label>B.Sc. (Bio) Admission Fee (INR):</label>
							<input type="number" name="admission_fee_bsc" value="<?php echo esc_attr( $s['admission_fee_bsc'] ?? '6000' ); ?>" class="regular-text" style="width: 100%;" />
							<p class="description" style="font-size: 11px; color: #64748b;">Annual / Admission fee charged for B.Sc. Biology applicants.</p>
						</div>
						<div class="form-row" style="grid-column: 1 / -1;">
							<label>Decoupled Frontend Website URL:</label>
							<input type="url" name="frontend_url" value="<?php echo esc_attr( $s['frontend_url'] ?? 'https://gurukepeeth-clg.vercel.app' ); ?>" class="regular-text" style="width: 100%;" placeholder="https://gurukepeeth-clg.vercel.app or http://localhost:5173" />
							<p class="description" style="font-size: 11px; color: #64748b;">The live frontend address for topbar previews and cross-origin CORS verification.</p>
						</div>
					</div>
				</div>
			</div>

			<p class="submit">
				<input type="submit" name="gurukapeeth_save_settings" class="button button-primary button-large" value="Save Institutional Settings" />
			</p>
		</form>
	</div>
	<?php
}

function gurukapeeth_render_homepage_page() {
	if ( isset( $_POST['gurukapeeth_save_hp'] ) && check_admin_referer( 'gurukapeeth_hp_nonce' ) ) {
		$hp_data = array(
			'hero_heading'      => sanitize_text_field( $_POST['hero_heading'] ?? '' ),
			'hero_subheading'   => sanitize_text_field( $_POST['hero_subheading'] ?? '' ),
			'stat_students'     => sanitize_text_field( $_POST['stat_students'] ?? '' ),
			'stat_faculty'      => sanitize_text_field( $_POST['stat_faculty'] ?? '' ),
			'stat_programs'     => sanitize_text_field( $_POST['stat_programs'] ?? '' ),
			'stat_placement'    => sanitize_text_field( $_POST['stat_placement'] ?? '' ),
			'initiative_title'  => sanitize_text_field( $_POST['initiative_title'] ?? '' ),
			'initiative_desc'   => sanitize_textarea_field( $_POST['initiative_desc'] ?? '' ),
		);

		update_option( 'gurukapeeth_homepage_data', $hp_data );
		echo '<div class="notice notice-success is-dismissible"><p>Homepage content successfully updated and synced!</p></div>';
	}

	$hp = get_option( 'gurukapeeth_homepage_data', array() );
	?>
	<div class="wrap gurukapeeth-admin-wrap">
		<h1>Homepage Section Builder</h1>
		<p class="subtitle">Customize key zones on the React homepage (Zone 2 Hero Banner, Zone 6 Impact Stats, Zone 10 Institutional Initiatives).</p>

		<form method="post" action="">
			<?php wp_nonce_field( 'gurukapeeth_hp_nonce' ); ?>
			<div class="gurukapeeth-form-grid">
				<div class="form-section">
					<h3>Zone 2: Hero Banner Text</h3>
					<div class="form-row">
						<label>Hero Headline:</label>
						<input type="text" name="hero_heading" value="<?php echo esc_attr( $hp['hero_heading'] ?? 'Empowering Minds, Transforming Futures in Southern Rajasthan' ); ?>" class="large-text" />
					</div>
					<div class="form-row">
						<label>Hero Subheading:</label>
						<input type="text" name="hero_subheading" value="<?php echo esc_attr( $hp['hero_subheading'] ?? 'Affiliated with Govind Guru Tribal University (GGTU), Banswara & Approved by Govt. of Rajasthan' ); ?>" class="large-text" />
					</div>
				</div>

				<div class="form-section">
					<h3>Zone 6: Impact Numbers & Statistics</h3>
					<div class="form-row">
						<label>Total Enrolled Students:</label>
						<input type="text" name="stat_students" value="<?php echo esc_attr( $hp['stat_students'] ?? '2,400+' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Qualified Faculty Members:</label>
						<input type="text" name="stat_faculty" value="<?php echo esc_attr( $hp['stat_faculty'] ?? '48+' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Degree Programs Offered:</label>
						<input type="text" name="stat_programs" value="<?php echo esc_attr( $hp['stat_programs'] ?? '12+' ); ?>" class="regular-text" />
					</div>
					<div class="form-row">
						<label>Success / Pass Rate:</label>
						<input type="text" name="stat_placement" value="<?php echo esc_attr( $hp['stat_placement'] ?? '94%' ); ?>" class="regular-text" />
					</div>
				</div>
			</div>

			<p class="submit">
				<input type="submit" name="gurukapeeth_save_hp" class="button button-primary button-large" value="Save Homepage Configurations" />
			</p>
		</form>
	</div>
	<?php
}
